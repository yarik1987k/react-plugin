import React from 'react';
import Posts from '../Posts';

function LayoutBlogD() {
  return (
    <div className="app-layout blog-d">    
      <Posts></Posts>
    </div>
  )
}

export default LayoutBlogD;